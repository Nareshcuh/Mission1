import React from 'react';
import SerialForm from '../Components/Serial/SerialForm';
import CitContainer from '../Components/Container';

const NotFound = ()=> {
  return (
    <CitContainer>
       <div>Not Found</div>       
    </CitContainer>
  );
}

export default NotFound;